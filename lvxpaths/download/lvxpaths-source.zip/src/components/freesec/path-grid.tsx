"use client";

import { PathCard } from "./path-card";
import { useFreesec, selectPaths } from "@/store/freesec";

/**
 * Responsive grid of all path cards.
 * 1 col on mobile, 2 cols on sm, 3 cols on lg.
 */
export function PathGrid() {
  const paths = useFreesec(selectPaths);
  if (paths.length === 0) return null;

  return (
    <div
      id="paths"
      className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3"
    >
      {paths.map((p) => (
        <PathCard key={p.id} pathId={p.id} />
      ))}
    </div>
  );
}
