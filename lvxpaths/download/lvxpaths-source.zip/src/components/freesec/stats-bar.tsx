"use client";

import { useMemo } from "react";
import { Layers, BookOpen, Clock, CheckCircle2, type LucideIcon } from "lucide-react";
import { useFreesec } from "@/store/freesec";
import { formatHours, totalHoursForItems } from "@/lib/catalog";
import { completionRate } from "@/lib/progress";

/**
 * Overall catalog stats — total paths, total free resources, est. total
 * hours, and the user's overall completion percentage (from localStorage).
 */
export function StatsBar() {
  const catalog = useFreesec((s) => s.catalog);
  const progress = useFreesec((s) => s.progress);

  const stats = useMemo(() => {
    if (!catalog) return null;
    const allIds = catalog.items.map((i) => i.id);
    return {
      totalPaths: catalog.paths.length,
      totalItems: catalog.items.length,
      totalHours: totalHoursForItems(catalog.items),
      rate: completionRate(allIds, progress),
    };
  }, [catalog, progress]);

  if (!stats) return null;

  const cards: {
    label: string;
    value: string | number;
    icon: LucideIcon;
    accent?: boolean;
  }[] = [
    { label: "Learning paths", value: stats.totalPaths, icon: Layers },
    { label: "Free resources", value: stats.totalItems, icon: BookOpen },
    { label: "Est. total hours", value: formatHours(stats.totalHours), icon: Clock },
    {
      label: "Your completion",
      value: `${stats.rate.pct}%`,
      icon: CheckCircle2,
      accent: stats.rate.pct > 0,
    },
  ];

  return (
    <section
      aria-label="Catalog overview"
      className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4"
    >
      {cards.map((card) => (
        <div key={card.label} className="fs-glass rounded-xl p-4 sm:p-5">
          <div className="flex items-start justify-between">
            <span className="text-xs uppercase tracking-wider text-muted-foreground">
              {card.label}
            </span>
            <card.icon
              className={`h-4 w-4 ${
                card.accent ? "text-primary" : "text-muted-foreground/60"
              }`}
            />
          </div>
          <div className="mt-2 text-2xl font-bold tracking-tight fs-mono sm:text-3xl">
            {card.value}
          </div>
          {card.label === "Your completion" && (
            <div className="mt-1 text-xs text-muted-foreground fs-mono">
              {stats.rate.done} / {stats.rate.total} items
            </div>
          )}
        </div>
      ))}
    </section>
  );
}
