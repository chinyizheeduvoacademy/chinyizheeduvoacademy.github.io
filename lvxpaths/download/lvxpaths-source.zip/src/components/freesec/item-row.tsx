"use client";

import { useState } from "react";
import {
  ExternalLink,
  CheckCircle2,
  Circle,
  Sparkles,
  Clock,
  Crosshair,
  BookOpen,
  ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useFreesec } from "@/store/freesec";
import { formatHours } from "@/lib/catalog";
import {
  type CatalogItem,
  type CatalogLevel,
  type CatalogType,
} from "@/lib/catalog";
import { LessonPanel } from "./lesson-panel";

const LEVEL_STYLES: Record<CatalogLevel, string> = {
  beginner: "bg-emerald-500/10 text-emerald-300 ring-1 ring-emerald-500/30",
  intermediate: "bg-amber-500/10 text-amber-300 ring-1 ring-amber-500/30",
  advanced: "bg-rose-500/10 text-rose-300 ring-1 ring-rose-500/30",
};

const TYPE_LABELS: Record<CatalogType, string> = {
  course: "Course",
  videos: "Videos",
  interactive: "Interactive",
  labs: "Labs",
  ctf: "CTF",
  reference: "Reference",
  tool: "Tool",
  articles: "Articles",
};

interface ItemRowProps {
  item: CatalogItem;
  /** 1-based display index. */
  index: number;
}

/**
 * A single resource row inside a path. Click the checkbox to toggle
 * completion in localStorage. The external link opens the official resource
 * in a new tab with `rel="noopener noreferrer"`. The "View lesson" button
 * expands an AI-generated lesson panel below the row — original teaching
 * content that complements (never reproduces) the resource.
 *
 * Per AGENTS.md hard rule #4, all dynamic text is rendered as React children
 * (auto-escaped) — never as `dangerouslySetInnerHTML`.
 */
export function ItemRow({ item, index }: ItemRowProps) {
  const done = useFreesec((s) => s.progress[item.id] != null);
  const toggle = useFreesec((s) => s.toggleItem);
  const [lessonOpen, setLessonOpen] = useState(false);

  return (
    <li className="space-y-2">
      <div
        className={cn(
          "fs-glass group relative flex items-start gap-3 rounded-xl p-4 transition-colors sm:p-5",
          done && "bg-primary/[0.04] ring-1 ring-primary/30"
        )}
      >
        {/* Number + checkbox column */}
        <div className="flex flex-col items-center gap-1 pt-0.5">
          <span className="fs-mono text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
            {String(index).padStart(2, "0")}
          </span>
          <button
            type="button"
            role="checkbox"
            aria-checked={done}
            aria-label={`${done ? "Mark incomplete" : "Mark complete"}: ${item.title}`}
            onClick={() => toggle(item.id)}
            className={cn(
              "grid h-7 w-7 place-items-center rounded-md border transition-all duration-200",
              done
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-secondary/30 text-muted-foreground hover:border-primary/60 hover:text-primary"
            )}
          >
            {done ? (
              <CheckCircle2 className="h-4 w-4" />
            ) : (
              <Circle className="h-4 w-4" />
            )}
          </button>
        </div>

        {/* Content column */}
        <div className="min-w-0 flex-1">
          <h4
            className={cn(
              "text-sm font-semibold leading-snug",
              done && "text-muted-foreground line-through decoration-primary/50"
            )}
          >
            {item.title}
          </h4>

          <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[11px]">
            {item.offsec && (
              <span className="inline-flex items-center gap-0.5 rounded bg-rose-500/10 px-1.5 py-0.5 font-medium text-rose-300 ring-1 ring-rose-500/30">
                <Crosshair className="h-3 w-3" />
                OffSec
              </span>
            )}
            {item.ai_assisted && (
              <span className="inline-flex items-center gap-0.5 rounded bg-primary/10 px-1.5 py-0.5 font-medium text-primary ring-1 ring-primary/30">
                <Sparkles className="h-3 w-3" />
                AI
              </span>
            )}
            <span className="rounded bg-secondary/60 px-1.5 py-0.5 font-medium text-foreground/80">
              {item.provider}
            </span>
            <span className="rounded bg-secondary/40 px-1.5 py-0.5 text-muted-foreground">
              {TYPE_LABELS[item.type]}
            </span>
            <span
              className={cn(
                "rounded px-1.5 py-0.5 font-medium capitalize",
                LEVEL_STYLES[item.level]
              )}
            >
              {item.level}
            </span>
            {item.hours_est > 0 && (
              <span className="fs-mono inline-flex items-center gap-0.5 rounded bg-secondary/40 px-1.5 py-0.5 text-muted-foreground">
                <Clock className="h-3 w-3" />
                {formatHours(item.hours_est)}
              </span>
            )}
            {item.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="rounded bg-primary/[0.07] px-1.5 py-0.5 text-primary/90"
              >
                #{tag}
              </span>
            ))}
          </div>

          {item.free_note && (
            <div className="mt-2 flex items-start gap-1.5 rounded-lg border border-primary/20 bg-primary/[0.05] px-2.5 py-1.5 text-[11px] leading-snug text-primary/90">
              <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-primary" />
              <span>{item.free_note}</span>
            </div>
          )}

          {/* View lesson button */}
          <button
            type="button"
            onClick={() => setLessonOpen((v) => !v)}
            aria-expanded={lessonOpen}
            aria-controls={`lesson-panel-${item.id}`}
            className={cn(
              "mt-3 inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-medium transition-colors",
              lessonOpen
                ? "border-primary/40 bg-primary/10 text-primary"
                : "border-border bg-secondary/40 text-foreground/80 hover:border-primary/40 hover:bg-primary/10 hover:text-primary"
            )}
          >
            <BookOpen className="h-3 w-3" />
            {lessonOpen ? "Hide lesson" : "View lesson"}
            <ChevronDown
              className={cn(
                "h-3 w-3 transition-transform duration-200",
                lessonOpen && "rotate-180"
              )}
            />
          </button>
        </div>

        {/* External link column */}
        <a
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`Open ${item.provider} resource in a new tab`}
          className="inline-flex h-9 w-9 shrink-0 items-center justify-center self-center rounded-lg border border-border bg-secondary/40 text-muted-foreground transition-all hover:border-primary/50 hover:bg-primary/10 hover:text-primary"
        >
          <ExternalLink className="h-4 w-4" />
        </a>
      </div>

      {/* AI lesson panel — expands below the row */}
      {lessonOpen && (
        <div id={`lesson-panel-${item.id}`} role="region" aria-label={`AI lesson for ${item.title}`}>
          <LessonPanel
            itemId={item.id}
            onClose={() => setLessonOpen(false)}
          />
        </div>
      )}
    </li>
  );
}
