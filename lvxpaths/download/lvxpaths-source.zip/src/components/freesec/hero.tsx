"use client";

import { ShieldCheck, ArrowDown, Github, Sparkles } from "lucide-react";

/**
 * Hero / mission section. Sets the tone: free, legal, curated — for
 * students who can't afford paid training. The user mentioned a future
 * fundraising campaign, so we surface a "fundraising soon" line gently.
 */
export function Hero() {
  const scrollToPaths = () => {
    document
      .getElementById("paths")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section className="relative overflow-hidden rounded-2xl fs-glass-strong px-6 py-10 sm:px-10 sm:py-14">
      {/* Ambient emerald glow */}
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-70" aria-hidden>
        <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
      </div>

      <div className="max-w-3xl">
        <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium uppercase tracking-wider text-primary">
          <ShieldCheck className="h-3.5 w-3.5" />
          Free · Legal · Curated
        </span>

        <h1 className="mt-5 text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl md:text-5xl">
          Cybersecurity learning paths that cost{" "}
          <span className="bg-gradient-to-r from-primary via-emerald-300 to-emerald-500 bg-clip-text text-transparent">
            zero.
          </span>
        </h1>

        <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
          Structured paths aggregating{" "}
          <span className="font-medium text-foreground">
            only free, official resources
          </span>{" "}
          — Linux privesc, Windows privesc, CCNA, bug bounty, blue team. We
          link to the authors&apos; own free versions. We never host, mirror,
          or proxy anything.
        </p>

        <div className="mt-3 flex items-start gap-1.5 rounded-lg border border-primary/20 bg-primary/[0.05] px-3 py-2 text-xs leading-relaxed text-primary/90">
          <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
          <span>
            Built for Malaysian and global students with no budget for paid
            training. A fundraising campaign is coming soon to help expand
            coverage.
          </span>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={scrollToPaths}
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:bg-primary/90 hover:shadow-primary/30"
          >
            Explore paths
            <ArrowDown className="h-4 w-4" />
          </button>
          <a
            href="https://github.com/chinyizheeduvoacademy/chinyizheeduvoacademy.github.io"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-lg border border-border bg-secondary/40 px-4 py-2.5 text-sm font-medium text-foreground/90 transition-colors hover:bg-secondary/70 hover:text-foreground"
          >
            <Github className="h-4 w-4" />
            View source
          </a>
        </div>
        <p className="mt-4 text-xs text-muted-foreground/70">
          Curated by{" "}
          <a
            href="https://github.com/leviathan-offsec"
            target="_blank"
            rel="noopener noreferrer"
            className="font-medium text-primary/90 underline-offset-4 hover:underline"
          >
            Chin Yi Zhe
          </a>{" "}
          · OffSec practitioner · Kuala Lumpur
        </p>
      </div>
    </section>
  );
}
