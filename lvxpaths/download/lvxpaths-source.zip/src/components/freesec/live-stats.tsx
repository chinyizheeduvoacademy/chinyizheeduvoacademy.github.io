"use client";

import { useEffect, useState } from "react";
import { Users, CheckCircle2, Sparkles, Activity, Globe } from "lucide-react";
import { useFreesec } from "@/store/freesec";
import { cn } from "@/lib/utils";

interface StatsResponse {
  total_learners: number;
  total_completions: number;
  total_curator_queries: number;
  top_items: { item_id: string; completions: number }[];
  top_paths: { path_id: string; completions: number }[];
  active_learners_24h: number;
  source: "clickhouse" | "sandbox";
  error?: string;
}

/**
 * Live global stats widget — mirrors LvxCloud's real-time counters but for
 * learning telemetry instead of threat intel. Reads from /api/stats.
 *
 * In the sandbox the source is "sandbox" (in-memory store); in production
 * (with CH_URL / CH_USER / CH_PASSWORD env vars set) it reads from
 * ClickHouse Cloud.
 */
export function LiveStats() {
  const [stats, setStats] = useState<StatsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const catalog = useFreesec((s) => s.catalog);

  // Fetch stats on mount + every 60s (matches the /api/stats cache TTL).
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch("/api/stats", { cache: "no-store" });
        const data = (await res.json()) as StatsResponse;
        if (!cancelled) {
          setStats(data);
          setLoading(false);
        }
      } catch {
        if (!cancelled) setLoading(false);
      }
    };
    void load();
    const interval = window.setInterval(load, 60_000);
    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, []);

  // Resolve top_items / top_paths IDs to catalog entries for display.
  const itemMap = catalog
    ? new Map(catalog.items.map((i) => [i.id, i]))
    : new Map();
  const pathMap = catalog
    ? new Map(catalog.paths.map((p) => [p.id, p]))
    : new Map();

  const cards: { label: string; value: string; icon: typeof Users; accent?: boolean }[] = [
    {
      label: "Active learners",
      value: stats ? String(stats.active_learners_24h) : "—",
      icon: Activity,
      accent: true,
    },
    {
      label: "Total learners",
      value: stats ? stats.total_learners.toLocaleString() : "—",
      icon: Users,
    },
    {
      label: "Items completed",
      value: stats ? stats.total_completions.toLocaleString() : "—",
      icon: CheckCircle2,
    },
    {
      label: "Curator queries",
      value: stats ? stats.total_curator_queries.toLocaleString() : "—",
      icon: Sparkles,
    },
  ];

  return (
    <section
      aria-label="Live platform stats"
      className="fs-glass relative overflow-hidden rounded-2xl p-5 sm:p-6"
    >
      <div
        className="pointer-events-none absolute -right-20 -top-20 h-40 w-40 rounded-full bg-primary/10 blur-3xl"
        aria-hidden
      />
      <div className="relative">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold tracking-tight">
              Live platform stats
            </h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Anonymous telemetry from everyone learning here. No accounts,
              no PII — just counts.
            </p>
          </div>
          {stats && (
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider",
                stats.source === "clickhouse"
                  ? "bg-primary/10 text-primary ring-1 ring-primary/30"
                  : "bg-secondary/40 text-muted-foreground ring-1 ring-border"
              )}
            >
              <span
                className={cn(
                  "h-1.5 w-1.5 rounded-full",
                  stats.source === "clickhouse"
                    ? "bg-primary animate-pulse"
                    : "bg-muted-foreground"
                )}
              />
              {stats.source === "clickhouse" ? "ClickHouse" : "sandbox"}
            </span>
          )}
        </div>

        {/* Counter grid */}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {cards.map((card) => (
            <div key={card.label}>
              <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                <card.icon
                  className={cn(
                    "h-3 w-3",
                    card.accent ? "text-primary" : "text-muted-foreground/70"
                  )}
                />
                {card.label}
              </div>
              <div className="fs-mono mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
                {loading ? (
                  <span className="inline-block h-7 w-12 animate-pulse rounded bg-muted-foreground/15" />
                ) : (
                  card.value
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Top items / paths */}
        {stats && !loading && (stats.top_items.length > 0 || stats.top_paths.length > 0) && (
          <div className="mt-5 grid gap-4 border-t border-border/40 pt-4 sm:grid-cols-2">
            {stats.top_paths.length > 0 && (
              <div>
                <p className="mb-2 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  <Globe className="h-3 w-3" />
                  Top paths this week
                </p>
                <ol className="space-y-1.5">
                  {stats.top_paths.map((p, i) => {
                    const path = pathMap.get(p.path_id);
                    return (
                      <li
                        key={p.path_id}
                        className="flex items-center justify-between gap-2 text-xs"
                      >
                        <span className="flex min-w-0 items-center gap-1.5">
                          <span className="fs-mono text-muted-foreground/60">
                            {String(i + 1).padStart(2, "0")}
                          </span>
                          <span className="truncate text-foreground/90">
                            {path?.name ?? p.path_id}
                          </span>
                        </span>
                        <span className="fs-mono shrink-0 font-semibold text-primary">
                          {p.completions}
                        </span>
                      </li>
                    );
                  })}
                </ol>
              </div>
            )}
            {stats.top_items.length > 0 && (
              <div>
                <p className="mb-2 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  <CheckCircle2 className="h-3 w-3" />
                  Top resources this week
                </p>
                <ol className="space-y-1.5">
                  {stats.top_items.map((it, i) => {
                    const item = itemMap.get(it.item_id);
                    return (
                      <li
                        key={it.item_id}
                        className="flex items-center justify-between gap-2 text-xs"
                      >
                        <span className="flex min-w-0 items-center gap-1.5">
                          <span className="fs-mono text-muted-foreground/60">
                            {String(i + 1).padStart(2, "0")}
                          </span>
                          <span className="truncate text-foreground/90">
                            {item?.title ?? it.item_id}
                          </span>
                        </span>
                        <span className="fs-mono shrink-0 font-semibold text-primary">
                          {it.completions}
                        </span>
                      </li>
                    );
                  })}
                </ol>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
