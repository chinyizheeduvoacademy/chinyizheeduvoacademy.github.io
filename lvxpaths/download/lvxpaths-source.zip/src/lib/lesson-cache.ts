/**
 * FreeSec Paths — per-item lesson cache.
 *
 * Lessons are AI-generated and the LLM call is ~3s, so we cache the response
 * per-item in localStorage to avoid regenerating on every visit. Cache key
 * shape: `freesec_lesson_<itemId>` → { generatedAt: ISO, payload: Lesson }.
 *
 * No expiry — a lesson for a given catalog item doesn't change unless the
 * item itself changes (catalog version bump). The catalog version is
 * included in the cache key prefix so bumping `catalog.version` invalidates
 * all stale lessons.
 */

const KEY_PREFIX = "freesec_lesson_";
const CATALOG_VERSION_KEY = "freesec_lesson_v";

export interface Lesson {
  learningObjectives: string[];
  focusAreas: { topic: string; why: string }[];
  commonPitfalls: { mistake: string; fix: string }[];
  selfCheck: string[];
  prerequisites: string;
  nextStep: string;
  estimatedTime: string;
}

interface CachedLesson {
  generatedAt: string;
  payload: Lesson;
}

function versionedKey(itemId: string, version: number): string {
  return `${KEY_PREFIX}${CATALOG_VERSION_KEY}${version}_${itemId}`;
}

/** Read a cached lesson. Returns null on server, on cache miss, or on schema mismatch. */
export function readLesson(itemId: string, version: number): Lesson | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(versionedKey(itemId, version));
    if (!raw) return null;
    const cached = JSON.parse(raw) as CachedLesson;
    if (!cached || typeof cached !== "object" || !cached.payload) return null;
    return cached.payload;
  } catch {
    return null;
  }
}

/** Persist a lesson. */
export function writeLesson(
  itemId: string,
  version: number,
  lesson: Lesson
): void {
  if (typeof window === "undefined") return;
  try {
    const cached: CachedLesson = {
      generatedAt: new Date().toISOString(),
      payload: lesson,
    };
    window.localStorage.setItem(
      versionedKey(itemId, version),
      JSON.stringify(cached)
    );
  } catch {
    /* Quota exceeded / disabled storage — silently ignore. */
  }
}

/** Drop every cached lesson (used by the reset button). */
export function clearAllLessons(): void {
  if (typeof window === "undefined") return;
  try {
    const keysToRemove: string[] = [];
    for (let i = 0; i < window.localStorage.length; i++) {
      const key = window.localStorage.key(i);
      if (key && key.startsWith(KEY_PREFIX)) keysToRemove.push(key);
    }
    keysToRemove.forEach((k) => window.localStorage.removeItem(k));
  } catch {
    /* ignore */
  }
}

export { KEY_PREFIX, CATALOG_VERSION_KEY };
