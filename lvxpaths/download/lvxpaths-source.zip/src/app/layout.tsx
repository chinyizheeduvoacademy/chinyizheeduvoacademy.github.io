import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FreeSec Paths — Free & Legal Cybersecurity Learning",
  description:
    "A free, curated catalog of official cybersecurity learning resources. Linux privesc, Windows privesc, CCNA, bug bounty, blue team — all from the authors' own free versions. We link, we never host.",
  keywords: [
    "free cybersecurity training",
    "free security courses",
    "CCNA free",
    "Linux privesc",
    "Windows privesc",
    "bug bounty free",
    "blue team free",
    "PortSwigger Web Security Academy",
    "Professor Messer",
    "TryHackMe free",
    "cybersecurity for students",
  ],
  authors: [{ name: "FreeSec Paths", url: "https://github.com/chinyizheeduvoacademy" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "FreeSec Paths — Free & Legal Cybersecurity Learning",
    description:
      "Curated learning paths aggregating only free, official security resources. Built for students who can't afford paid training.",
    url: "https://chinyizheeduvoacademy.github.io",
    siteName: "FreeSec Paths",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FreeSec Paths — Free & Legal Cybersecurity Learning",
    description:
      "Curated learning paths aggregating only free, official security resources. Built for students who can't afford paid training.",
  },
};

export const viewport: Viewport = {
  themeColor: "#0a0f1a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
