-- ============================================================
-- FreeSec Paths — ClickHouse Schema (matches LvxCloud pattern)
-- ============================================================
-- Engine: ReplacingMergeTree / MergeTree (same engine family as
-- lvxcloud.services) so we can reuse the same ClickHouse Cloud instance
-- (GCP asia-southeast1) under a separate `freesec` database.
--
-- Deploy: clickhouse-client --host <CH_URL> --user <CH_USER>
--         --password <CH_PASSWORD> --queries-file sql/freesec_schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS freesec;

-- ------------------------------------------------------------
-- Table 1: anonymous learning events (the core telemetry stream)
-- ------------------------------------------------------------
-- Mirrors lvxcloud.services shape: ORDER BY (event_type, occurred_at)
-- for fast range scans on the most common queries.
CREATE TABLE IF NOT EXISTS freesec.events (
    event_id       String,                                  -- UUIDv4
    event_type     Enum8(
                       'item_complete'   = 1,
                       'item_incomplete' = 2,
                       'lesson_viewed'   = 3,
                       'curator_query'   = 4,
                       'path_viewed'     = 5
                   ),
    item_id        LowCardinality(String) DEFAULT '',       -- catalog item id (if applicable)
    path_id        LowCardinality(String) DEFAULT '',       -- catalog path id (if applicable)
    session_id     String,                                  -- anonymous per-browser UUID (no PII)
    session_country LowCardinality(String) DEFAULT '',      -- CF-IPCountry header (no PII)
    occurred_at    DateTime DEFAULT now()
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(occurred_at)
ORDER BY (event_type, occurred_at, item_id)
SETTINGS index_granularity = 8192;

-- ------------------------------------------------------------
-- Table 2: AI curator queries (for tuning prompt quality)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS freesec.curator_queries (
    query_id        String,                                 -- UUIDv4
    session_id      String,
    query_text      String,                                  -- user's natural-language query
    matched_items   Array(String),                           -- returned item ids
    matched_paths   Array(String),                           -- returned path ids
    response_ms     UInt32,                                  -- LLM response time
    occurred_at    DateTime DEFAULT now()
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(occurred_at)
ORDER BY (occurred_at, session_id);

-- ------------------------------------------------------------
-- Materialized view 1: daily item completion rollup
-- ------------------------------------------------------------
-- This is what powers the "Live stats" widget on the home page
-- (top-completed items this week, completion velocity, etc.).
CREATE MATERIALIZED VIEW IF NOT EXISTS freesec.item_completion_daily
ENGINE = SummingMergeTree()
PARTITION BY toYYYYMM(day)
ORDER BY (item_id, day)
AS
SELECT
    item_id,
    toStartOfDay(occurred_at) AS day,
    countIf(event_type = 1) AS completions,
    countIf(event_type = 2) AS incompletes
FROM freesec.events
WHERE event_type IN (1, 2) AND item_id != ''
GROUP BY item_id, toStartOfDay(occurred_at);

-- ------------------------------------------------------------
-- Materialized view 2: daily active learners
-- ------------------------------------------------------------
CREATE MATERIALIZED VIEW IF NOT EXISTS freesec.active_learners_daily
ENGINE = SummingMergeTree()
PARTITION BY toYYYYMM(day)
ORDER BY (day, session_country)
AS
SELECT
    toStartOfDay(occurred_at) AS day,
    session_country,
    uniqExact(session_id) AS unique_sessions
FROM freesec.events
GROUP BY toStartOfDay(occurred_at), session_country;

-- ------------------------------------------------------------
-- Sample queries (for the /api/stats endpoint)
-- ------------------------------------------------------------
-- Total learners all-time:
--   SELECT uniqExact(session_id) FROM freesec.events;
--
-- Total completions all-time:
--   SELECT countIf(event_type = 1) FROM freesec.events;
--
-- Top 5 most-completed items this week:
--   SELECT item_id, sum(completions) AS c
--   FROM freesec.item_completion_daily
--   WHERE day >= now() - INTERVAL 7 DAY
--   GROUP BY item_id ORDER BY c DESC LIMIT 5;
--
-- Active learners last 24h by country:
--   SELECT session_country, sum(unique_sessions) AS learners
--   FROM freesec.active_learners_daily
--   WHERE day >= now() - INTERVAL 1 DAY
--   GROUP BY session_country ORDER BY learners DESC LIMIT 10;
